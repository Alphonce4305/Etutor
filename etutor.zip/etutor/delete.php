<?php
include_once 'dbconfig.php';
session_start();
$logged_user = $_SESSION['u_id'];
$item_code = $_GET['item'];


//Delete Bookings
$sql ="DELETE FROM `bookings` WHERE `bookings`.`id` = '$item_code' AND parent_id ='$logged_user'";
$query = Mysqli_query($conn,$sql);
if ($query == true) {
	header('location:parent.php?msg=success');
		}else{
	header('location:parent.php?msg=failed');
 	}
?>