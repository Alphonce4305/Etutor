
<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-danger">
  <div class="container-fluid text-white">
    <a style="font-size: 24px;color: #000; font-weight: bold; font-family: 'Zen Dots', cursive;">E-tutor </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse text-white" id="navbarSupportedContent">
  <ul class="nav justify-content-end" style="text-transform: uppercase;">
        
        </li>
          <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#subjectForm" id="link">Subjects</a></li>
          <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#setprofile" id="link">Profile</a></li>
          <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#setSlot" id="link">Set Slot</a></li>
          <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#mySubjects" id="link">My Subjects</a></li>
          <li class="nav-item"><a href="logout.php" class="nav-link" id="link">Logout</a></li>
       
          </li>
    </div>

      </ul>  </div>
</nav>

<style type="text/css">

  ul>li{
    font-size: 16px;
    color: white;
  }
  .nav-link{color: #FFF;}
  .nav-link:hover{color: #000;}
</style>


