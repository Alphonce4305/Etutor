

<?php

$host ="localhost";
$username="root";
$pass="";
$db="teacher";

// create connection
$conn = new mysqli($host,$username,$pass);
//check connection
if ($conn->connect_error) {
	die("Connection Failed !".$conn->connect_error);
}else{
	//echo "Connected Successfully";
}
// Connect to the DB 
Mysqli_select_db($conn,$db)or die("Not Connected...");

 ?>