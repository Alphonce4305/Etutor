
<div style="clear: both;"></div>
<footer style="text-align: center;color: #000;">
	<small> &copy;Designed By: <span>Alphonce Odhiambo</span></small>
</footer>
</html>
<script src="js/jquery.js"></script>
     <script src="js/bootstrap.js"></script>
	 <script src="js/style.js"></script>
	 <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.24/datatables.min.js"></script>

<script type="text/javascript">
	$(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>